function y = hwr(x)
% Half-Wave Rectifier

y = 0.5 * (x + abs(x));
clear all, close all
[Fn,Pn] = uigetfile('*.wav', 'Choisir le fichier son � traiter');
FichierListe=[Pn Fn];
%[y,Fe,nbits] = waveread(FichierListe);
[y,Fe] = audioread(FichierListe);
% possibilit� de ne prendre qu'une partie du signal - par ex. 1 seconde d'un signal � 44100 Hz - d�commenter la ligne suivante)
%y = y(1:44100);
%aux = analyse(y,Fe,0,Fe/2,1024);
% pour ne prendre qu'une seule piste du signal
y=y(:,1);

[X,dBA]=analyzeSignal(y,Fe)